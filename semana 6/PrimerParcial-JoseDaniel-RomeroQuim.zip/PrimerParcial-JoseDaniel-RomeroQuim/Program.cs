﻿class PrimerParcial_DanielRomero
{
    static void Main(string[]args)
    {
        Console.WriteLine("Ingrese 3 numeros");
        string num_1 = Console.ReadLine();
        string num_2 = Console.ReadLine();
        string num_3 = Console.ReadLine();

        int num1 = Convert.ToInt32(num_1);
        int num2 = Convert.ToInt32(num_2);
        int num3 = Convert.ToInt32(num_3);
        
            if (num1 % 2 == 0)
            {
                Console.WriteLine("El numero es par");
            }
            else
            {
                Console.WriteLine("El numero es impar");
            }
        
            if (num2 % 2 == 0)
            {
                Console.WriteLine("El numero es par");
            }
            else
            {
                Console.WriteLine("El numero es impar");
            }
        
            if (num3 % 2 == 0)
            {
                Console.WriteLine("El numero es par");
            }
            else
            {
                Console.WriteLine("El numero es impar");
            }

        Console.ReadKey();

    }
}
