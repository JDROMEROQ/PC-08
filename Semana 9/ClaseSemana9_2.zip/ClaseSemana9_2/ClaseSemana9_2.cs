﻿int[] numbers = { 4, 8, 15, 16, 23, 42 };
int total = 0; // Inicializar total fuera del bucle
bool found = false; // Inicializar found fuera del bucle
foreach (int number in numbers)
{
    total += number; 
    if (number == 42) // Podemos omitir las llaves de los if's
        found = true;
    
}
if (found)
    Console.WriteLine("Set contains 42");

Console.WriteLine($"Total: {total}");